package com.lijm.trans.dao;

import com.lijm.trans.entity.User;

import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/26 21:28
 * @describe
 */
public interface UserDao {

    Double findMoneyById(String id) throws SQLException;

    void updateMoneyById(String id, Double money ) throws SQLException;
}
