package com.lijm.trans.service;


import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/26 21:27
 * @describe
 */
public interface UserService {


    void transfer(String id, String toId, Double money) throws SQLException;

}
