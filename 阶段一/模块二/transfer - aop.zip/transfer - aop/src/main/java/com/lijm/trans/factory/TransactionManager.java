package com.lijm.trans.factory;

import com.lijm.trans.utils.ConnectionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/27 22:00
 * @describe  事务执行类
 */

public class TransactionManager {


    private ConnectionUtil connectionUtil;

    /**
     * 设置非自动提交事务
      * @throws SQLException
     */
    public void beginTransaction() throws SQLException {
        // 使用connect处理类，保证本次数据库操作是同一个请求
        connectionUtil.getCurrentThreadConn().setAutoCommit(false);
    }

    /**
     * 提交事务
     * @throws SQLException
     */
    public void commit() throws  SQLException {
        connectionUtil.getCurrentThreadConn().commit();
    }

    public void rollback() throws SQLException {
        System.out.println("完蛋了，报错");
        connectionUtil.getCurrentThreadConn().rollback();
    }

}
