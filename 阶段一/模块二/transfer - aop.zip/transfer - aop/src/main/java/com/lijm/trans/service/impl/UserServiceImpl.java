package com.lijm.trans.service.impl;

import com.lijm.trans.dao.UserDao;
import com.lijm.trans.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/26 21:27
 * @describe
 */
@Service("service")
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public void transfer(String id, String toId, Double money) throws SQLException {
        System.out.println("哈哈哈");
        // 获取小红的钱
        Double xiaoHong = userDao.findMoneyById(id);
        // 获取小花的钱
        Double xiaoHua = userDao.findMoneyById(toId);
        userDao.updateMoneyById(id,xiaoHong - money);
        int a = 1 / 0;
        userDao.updateMoneyById(toId, xiaoHua + money);
        System.out.println("haahah");
    }
}
