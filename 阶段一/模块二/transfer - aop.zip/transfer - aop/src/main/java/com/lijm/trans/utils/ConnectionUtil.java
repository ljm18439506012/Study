package com.lijm.trans.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/27 21:47
 * @describe
 */
@Component
public class ConnectionUtil {

    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;


    private ThreadLocal<Connection> threadLocal = new ThreadLocal<>();

    public Connection getCurrentThreadConn() throws SQLException {
        Connection connection = threadLocal.get();
        if (connection == null) {
            connection  = dataSource.getConnection();
            threadLocal.set(connection);
        }
        return connection;
    }
}
