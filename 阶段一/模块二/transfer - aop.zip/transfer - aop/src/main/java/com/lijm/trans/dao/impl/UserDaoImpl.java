package com.lijm.trans.dao.impl;

import com.lijm.trans.dao.UserDao;
import com.lijm.trans.entity.User;
import com.lijm.trans.utils.ConnectionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Lijm
 * @date 2020/10/26 21:28
 * @describe
 */
@Repository
public class UserDaoImpl implements UserDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 根据id 获取余额的方法
     * @param id
     * @return
     * @throws SQLException
     */
    @Override
    public Double findMoneyById(String id) throws SQLException {
        Connection connection = null;
        Double money = 0.0;
        String sql = "select * from users where id = ?";
        User user1 = jdbcTemplate.queryForObject(sql, new RowMapper<User>() {
            @Override
            public User mapRow(ResultSet resultSet, int i) throws SQLException {
                User user = new User();
                user.setId(resultSet.getString("id"));
                user.setUsername(resultSet.getString("username"));
                user.setSex(resultSet.getString("sex"));
                user.setMoney(resultSet.getDouble("money"));
                return user;
            }
        },id);
        money = user1.getMoney();
        return money;
    }

    /**
     * 更新余额的方法
     * @param id
     * @param money
     * @throws SQLException
     */
    @Override
    public void updateMoneyById(String id, Double money) throws SQLException {

        String sql = "update users set money = ? where id = ?";
        jdbcTemplate.update(sql,money,id);

    }

}
