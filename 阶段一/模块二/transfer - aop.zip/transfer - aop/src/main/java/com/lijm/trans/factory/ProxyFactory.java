package com.lijm.trans.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * @author Lijm
 * @date 2020/10/27 22:26
 * @describe
 */

public class ProxyFactory {


    private TransactionManager transactionManager;


    /**
     * object
     * @param obj 是委托对象
     * @return  代理对象
     */
    public Object getJdkProxy(final Object obj) {
        Proxy o = (Proxy)Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                transactionManager.beginTransaction();
                Object result = null;
                try {
                    result = method.invoke(obj, args);
                    transactionManager.commit();
                }catch (Exception e) {
                    transactionManager.rollback();
                    throw e;
                }
                return result;
            }
        });
        return o;
    }
}
