package com.lijm.trans.controller;


import com.lijm.trans.factory.ProxyFactory;
import com.lijm.trans.response.Result;
import com.lijm.trans.service.UserService;
import com.lijm.trans.utils.JsonUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Lijm
 * @date 2020/10/26 21:27
 * @describe
 */
@WebServlet(name="UserServlet",urlPatterns = "/transferServlet")
public class UserServlet extends HttpServlet {

    //private ProxyFactory proxyFactory = (ProxyFactory) BeansFactory.getBean("proxyFactory");

    private UserService userService;

    @Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(this.getServletContext());
        this.userService  = (UserService)context.getBean("service");
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("hahah");
        String fromCardNo = req.getParameter("fromCardNo");
        String toCardNo = req.getParameter("toCardNo");
        String money = req.getParameter("money");
        Double i = Double.parseDouble(money);
        Result result = new Result();
        try {
            userService.transfer(fromCardNo, toCardNo, i);
            result.setStatus("200");
            result.setMessage("请求成功");
        }catch (Exception e) {
            result.setStatus("500");
            result.setMessage("请求失败");
            e.printStackTrace();
        }
        // 写进响应体
        resp.setContentType("application/json;charset=utf-8");
        resp.getWriter().print(JsonUtils.object2Json(result));
        super.doPost(req, resp);
    }
}
