package com.lijm.trans.utils;

import org.springframework.stereotype.Component;

/**
 * @author Lijm
 * @date 2020/11/14 19:26
 * @describe
 */
@Component
public class LogUtils {


    public void vd1() {

    }

    /**
     * 业务逻辑开始之前执行
     */

    public void beforeMethod() {
        System.out.println("y业务逻辑开始之前执行");
    }

    /**
     * 业务逻辑之后执行
     */
    public void afterMethod() {
        System.out.println();
    }

    /**
     * 业务逻辑结束之后执行
     */
    public void exceMethod() {
        System.out.println("业务逻辑结束后执行");
    }

    /**
     * 业务逻辑出错之后执行
     */
    public void errMethod() {
        System.out.println("业务逻辑报错之后执行");
    }

    /**
     * 业务逻辑技术之后执行
     */
    public void successMethod() {
        System.out.println("正常结束之后执行");
    }
}
