package com.lagou.sqlSession;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface ParameterHandler {
    void setParameters(PreparedStatement var1, Object... params) throws Exception;
}
