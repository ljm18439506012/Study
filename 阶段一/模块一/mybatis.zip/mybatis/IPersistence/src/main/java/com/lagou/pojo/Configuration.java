package com.lagou.pojo;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 *  存在数据库基本信息
 * */
public class Configuration {
    /**
     *  数据源信息
     * */
    private DataSource dataSource;

    /**
     *  mapper信息
     *  这里先new出来,后边直接put值;
     *  如果用的时候在new,set,会导致覆盖,也有办法解决但是不如直接new方便;
     * */
    private Map<String,MappedStatement> mappedStatementMap = new HashMap<String, MappedStatement>();

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, MappedStatement> getMappedStatementMap() {
        return mappedStatementMap;
    }

    public void setMappedStatementMap(Map<String, MappedStatement> mappedStatementMap) {
        this.mappedStatementMap = mappedStatementMap;
    }
}
