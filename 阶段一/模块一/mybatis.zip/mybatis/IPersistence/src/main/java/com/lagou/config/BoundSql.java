package com.lagou.config;

import com.lagou.utils.ParameterMapping;

import java.util.List;

public class BoundSql {
    public String sql;

    public List<ParameterMapping> parameterMappingList;

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public List<ParameterMapping> getParameterMappingList() {
        return parameterMappingList;
    }

    public void setParameterMappingList(List<ParameterMapping> parameterMappingList) {
        this.parameterMappingList = parameterMappingList;
    }
}
