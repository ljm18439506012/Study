package com.lagou.sqlSession;

import com.lagou.config.BoundSql;
import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;
import com.lagou.utils.GenericTokenParser;
import com.lagou.utils.ParameterMapping;
import com.lagou.utils.ParameterMappingTokenHandler;

import java.sql.*;
import java.util.List;

public class SimpleExecutor implements Executor {
    public <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // 获取数据库连接
            connection = configuration.getDataSource().getConnection();

            // 获取sql语句
            String sql = mappedStatement.getSql();

            // 对sql进行转换
            BoundSql boundSql = getBoundSql(sql);

            preparedStatement = connection.prepareStatement(boundSql.getSql());

            DefaultParameterHandler defaultParameterHandler = new DefaultParameterHandler(configuration,boundSql,mappedStatement);
            // 设置参数
            defaultParameterHandler.setParameters(preparedStatement, params);

            // 执行sql
            preparedStatement.executeQuery();

            return (List<E>) new DefaultResultSetHandler(mappedStatement).handleResultSets(preparedStatement);
        }finally {
            preparedStatement.close();
            connection.close();
        }

    }

    public void update(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // 获取数据库连接
            connection = configuration.getDataSource().getConnection();

            // 获取sql语句
            String sql = mappedStatement.getSql();

            // 对sql进行转换
            BoundSql boundSql = getBoundSql(sql);

            preparedStatement = connection.prepareStatement(boundSql.getSql());

            // 设置参数
            DefaultParameterHandler defaultParameterHandler = new DefaultParameterHandler(configuration,boundSql,mappedStatement);
            defaultParameterHandler.setParameters(preparedStatement, params);

            // 执行sql
            preparedStatement.executeUpdate();
        }finally {
            preparedStatement.close();
            connection.close();
        }

    }



    /**
     * 完成对#{}的解析,1.将#{}使用?代替; 2.将#{}里面的值进行存储
     * */
    private BoundSql getBoundSql(String sql) {
        // 标记处理器,配合标记解析器使用,完成对占位符的解析处理
        ParameterMappingTokenHandler tokenHandler = new ParameterMappingTokenHandler();

        GenericTokenParser genericTokenParser = new GenericTokenParser("#{", "}", tokenHandler);
        // 解析sql
        String parseSql = genericTokenParser.parse(sql);

        // 拿到大括号的参数名称
        List<ParameterMapping> parameterMappings = tokenHandler.getParameterMappings();

        BoundSql boundSql = new BoundSql();
        boundSql.setSql(parseSql);
        boundSql.setParameterMappingList(parameterMappings);

        return boundSql;

    }


}
