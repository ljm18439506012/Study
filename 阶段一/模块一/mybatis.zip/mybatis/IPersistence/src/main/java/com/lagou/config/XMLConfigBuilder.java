package com.lagou.config;

import com.lagou.io.Resources;
import com.lagou.pojo.Configuration;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

/**
 *  解析configuration
 *  dom4j操作xml文档 : https://blog.csdn.net/qq_41860497/article/details/84339091#1%E3%80%81DOM4J%E7%AE%80%E4%BB%8B
 * */
public class XMLConfigBuilder {
    Configuration configuration;

    public XMLConfigBuilder(){
        this.configuration = new Configuration();
    }

    /**
     *  使用dom4j将配置文件解析封装到Configuration
     * */
    public Configuration parseConfig(InputStream inputStream) throws DocumentException, PropertyVetoException {
        Document document = new SAXReader().read(inputStream);

        // 获取xml根节点
        Element rootElement = document.getRootElement();

        // 解析property
        this.databaseElement(rootElement.selectNodes("//property"));

        // 解析mapper
        this.mapperElement(rootElement.selectNodes("//mapper"));
//        List<Element> mapperList = rootElement.selectNodes("//mapper");
//
//        for (Element element : mapperList) {
//            String mapperPath = element.attributeValue("resource");
//
//            InputStream resourceAsStream = Resources.getResourceAsStream(mapperPath);
//
//            XMLMapperBulider xmlMapperBulider = new XMLMapperBulider(configuration);
//            configuration = xmlMapperBulider.parseMapper(resourceAsStream);
//        }

        return configuration;
    }

    /**
     *  解析mapper.xml
     * */
    private void mapperElement(List<Element> mapperList) throws DocumentException {
        for (Element element : mapperList) {
            // 获取到mapper.xml路径
            String mapperPath = element.attributeValue("resource");

            // 加载为字节输入流
            InputStream resourceAsStream = Resources.getResourceAsStream(mapperPath);

            // 解析mapper.xml
            XMLMapperBulider xmlMapperBulider = new XMLMapperBulider(configuration);
            configuration = xmlMapperBulider.parseMapper(resourceAsStream);
        }
    }

    /**
     *  解析property
     * */
    private void databaseElement(List<Element> elementList) throws PropertyVetoException {
        // 用于存放数据库配置信息
        Properties properties = new Properties();

        // 遍历property,获取数据库配置信息
        for (Element element : elementList) {
            String name = element.attributeValue("name");
            String value = element.attributeValue("value");

            properties.setProperty(name, value);
        }

        // 创建一个连接池
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
        comboPooledDataSource.setDriverClass(properties.getProperty("driverClass"));
        comboPooledDataSource.setJdbcUrl(properties.getProperty("jdbcUrl"));
        comboPooledDataSource.setUser(properties.getProperty("user"));
        comboPooledDataSource.setPassword(properties.getProperty("password"));

        // 填充实体
        configuration.setDataSource(comboPooledDataSource);
    }

}
