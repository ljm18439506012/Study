package com.lagou.config;

import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;
import com.lagou.sqlSession.SqlCommandType;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.List;

public class XMLMapperBulider {

    private Configuration configuration;

    public XMLMapperBulider(Configuration configuration){
        this.configuration = configuration;
    }

    public Configuration parseMapper(InputStream inputStream) throws DocumentException {
        Document mapperDocument = new SAXReader().read(inputStream);

        // 获取根节点
        Element mapperElement = mapperDocument.getRootElement();

        // 获取namespace值
        String namespace = mapperElement.attributeValue("namespace");

        if(namespace != null && !"".equals(namespace)){
            // 解析标签
            this.buildStatementFromContext(namespace,mapperElement.selectNodes("select|insert|update|delete"));
        }

        return configuration;
//        List<Element> selectNodes = mapperElement.selectNodes("select|insert|update|delete");

//        List<Element> selectNodes = mapperElement.selectNodes("//select");
    }

    /**
     *  解析标签
     * */
    private void buildStatementFromContext(String namespace, List<Element> selectNodes) {
        for (Element selectNode : selectNodes) {
            String id = selectNode.attributeValue("id");
            String resultType = selectNode.attributeValue("resultType");
            String paramterType = selectNode.attributeValue("paramterType");
            String sql = selectNode.getTextTrim();
            // 获取标签名称,方便动态代理判断调用方法
            String nodeName = selectNode.getName();
            SqlCommandType sqlCommandType = SqlCommandType.valueOf(nodeName.toUpperCase());

            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setSql(sql);
            mappedStatement.setResultType(resultType);
            mappedStatement.setParamterType(paramterType);
            mappedStatement.setSqlCommandType(sqlCommandType);

            // key由 namespace + . + id组成
            configuration.getMappedStatementMap().put( namespace + "." + id, mappedStatement );
        }
    }

}
