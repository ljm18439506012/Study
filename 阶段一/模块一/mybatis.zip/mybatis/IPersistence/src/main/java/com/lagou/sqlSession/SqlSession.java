package com.lagou.sqlSession;

import java.util.List;

public interface SqlSession {
    // 查询符合条件的记录
    <E> List<E> selectList(String statementId, Object... params) throws Exception;

    // 查询一条记录
    <T> T selectOne(String statementId, Object... params) throws Exception;

    // 插入一条记录
    void insert(String statementId, Object... params) throws Exception;

    // 修改记录
    void update(String statementId, Object... params) throws Exception;

    // 删除记录
    void delete(String statementId, Object... params) throws Exception;

    // 使用JDK动态代理来为Dao接口生成代理对象,并返回
    <T> T getMapper(Class<?> mapperClass);
}
