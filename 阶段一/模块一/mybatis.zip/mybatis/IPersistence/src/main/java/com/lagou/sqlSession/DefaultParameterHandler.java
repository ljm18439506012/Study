package com.lagou.sqlSession;

import com.lagou.config.BoundSql;
import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;
import com.lagou.utils.ParameterMapping;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.util.List;

public class DefaultParameterHandler implements ParameterHandler {
    private Configuration configuration;
    private BoundSql boundSql;
    private MappedStatement mappedStatement;

    public DefaultParameterHandler(Configuration configuration, BoundSql boundSql, MappedStatement mappedStatement){
        this.configuration = configuration;
        this.boundSql = boundSql;
        this.mappedStatement = mappedStatement;
    }

    public void setParameters(PreparedStatement preparedStatement, Object... params) throws Exception {
        // 参数名
        List<ParameterMapping> parameterMappings = boundSql.getParameterMappingList();

        // 参数类型路径
        String paramterType = mappedStatement.getParamterType();
        // 反射获取class
        Class<?> paramterTypeClass = getClassType(paramterType);



        for (int i = 0; i < parameterMappings.size(); i++) {

            ParameterMapping parameterMapping = parameterMappings.get(i);
            // 对应的参数名称
            String content = parameterMapping.getContent();

            // 反射
            Field declaredField = paramterTypeClass.getDeclaredField(content);
            // 暴力访问
            declaredField.setAccessible(true);

            // 获取参数值 params[0] = User对象, 猜想 : 根据字段名到实体中获取对应的值
            Object o = declaredField.get(params[0]);

            // 为sql填充参数
            preparedStatement.setObject(i+1, o);
        }
    }

    private Class<?> getClassType(String paramterType) throws ClassNotFoundException {
        if(paramterType != null && !"".equals(paramterType)){
            Class<?> aClass = Class.forName(paramterType);
            return aClass;
        }
        return null;
    }
}
