package com.lagou.sqlSession;

public interface SqlSessionFactory {
    SqlSession openSession();
}
