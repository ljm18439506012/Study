package com.lagou.sqlSession;

import com.lagou.pojo.MappedStatement;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DefaultResultSetHandler implements ResultSetHandler {
    private MappedStatement mappedStatement;

    public DefaultResultSetHandler(MappedStatement mappedStatement){
        this.mappedStatement = mappedStatement;
    }

    public <E> List<E> handleResultSets(Statement stmt) throws Exception {
        ResultSet resultSet = null;
        try {
            resultSet = stmt.getResultSet();

            // 返回值类型路径
            String resultType = mappedStatement.getResultType();
            Class<?> resultTypeClass = getClassType(resultType);

            ArrayList<Object> es = new ArrayList<Object>();

            // 封装结果集
            while (resultSet.next()){
                // 创建一个对象
                Object o = resultTypeClass.newInstance();
                // 元数据
                ResultSetMetaData metaData = resultSet.getMetaData();

                for (int i = 1; i <= metaData.getColumnCount(); i++) {
                    // 字段名
                    String columnName = metaData.getColumnName(i);

                    // 获取值
                    Object value = resultSet.getObject(columnName);

                    // 使用反射或者内省,根据数据库表和实体的对应关系,进行封装
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(columnName, resultTypeClass);
                    // 获取Class的写方法
                    Method writeMethod = propertyDescriptor.getWriteMethod();

                    writeMethod.invoke(o, value);
                }
                es.add(o);
            }
            return (List<E>) es;

        }finally {
            resultSet.close();
        }

    }

    private Class<?> getClassType(String paramterType) throws ClassNotFoundException {
        if(paramterType != null && !"".equals(paramterType)){
            Class<?> aClass = Class.forName(paramterType);
            return aClass;
        }
        return null;
    }
}
