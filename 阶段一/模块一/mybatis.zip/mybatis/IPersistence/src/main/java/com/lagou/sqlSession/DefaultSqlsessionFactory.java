package com.lagou.sqlSession;

import com.lagou.pojo.Configuration;

public class DefaultSqlsessionFactory implements SqlSessionFactory {
    private Configuration configuration;

    public DefaultSqlsessionFactory(Configuration configuration){
        this.configuration = configuration;
    }

    public SqlSession openSession() {
        DefaultSqlSession defaultSqlSession = new DefaultSqlSession(configuration);
        return defaultSqlSession;
    }
}
