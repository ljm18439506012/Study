package com.lagou.sqlSession;

import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;

import java.lang.reflect.*;
import java.util.List;
import java.util.Map;

public class DefaultSqlSession implements SqlSession{
    private Configuration configuration;

    public DefaultSqlSession (Configuration configuration){
        this.configuration = configuration;
    }
    /**
     *  查询符合条件的记录
     * */
    public <E> List<E> selectList(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatementMap = configuration.getMappedStatementMap().get(statementId);

        SimpleExecutor simpleExecutor = new SimpleExecutor();
        List<Object> querys = simpleExecutor.query(configuration, mappedStatementMap, params);

        return (List<E>) querys;
    }

    /**
     *  查询一条记录
     * */
    public <T> T selectOne(String statementId, Object... params) throws Exception {
        List<Object> objects = selectList(statementId, params);

        if(objects.size() == 1){
            return (T) objects.get(0);
        }else {
            throw new RuntimeException("查询结果为空,或存在多条记录!");
        }

    }

    public void insert(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatementMap = configuration.getMappedStatementMap().get(statementId);

        SimpleExecutor simpleExecutor = new SimpleExecutor();
        simpleExecutor.update(configuration, mappedStatementMap, params);
    }

    public void update(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatementMap = configuration.getMappedStatementMap().get(statementId);

        SimpleExecutor simpleExecutor = new SimpleExecutor();
        simpleExecutor.update(configuration, mappedStatementMap, params);
    }

    public void delete(String statementId, Object... params) throws Exception {
        MappedStatement mappedStatementMap = configuration.getMappedStatementMap().get(statementId);

        SimpleExecutor simpleExecutor = new SimpleExecutor();
        simpleExecutor.update(configuration, mappedStatementMap, params);
    }

    /**
     *  使用JDK动态代理来为Dao接口生成代理对象,并返回
     *
     *  创建代理对象的要求:
     *           被代理类最少实现一个接口,如果没有则不能使用
     *       newProxyInstance方法的参数:
     *           ClassLoader: 类加载器
     *               他是用来加载代理对象字节码的,和被代理对象使用相同的类加载器,固定写法
     *           Class[]: 字节码数组
     *               他是让代理对象和被代理对象有相同方法,固定写法;
     *           InvocationHandler:用于提供增强的代码
     *               他是让我们写如何代理,我们一般都是写一个该接口的实现类,通常情况下时匿名内部类,但不是必须的;
     *
     * */
    public <T> T getMapper(Class<?> mapperClass) {
        Object proxyInstance = Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {
            /**
             *  作用 : 执行被代理对象的任何方法都会经过该方法
             *  方法参数的含义
             *  proxy :  代理对象的引用
             *  method : 当前执行的方法
             *  args :   当前执行方法所需的参数
             * @return 和被代理对象方法的返回值类型相同
             * */
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                // 获取方法名
                String name = method.getName();
                // 获取class
                String className = method.getDeclaringClass().getName();

                // 组成statmentid
                String statmentid = className + "." + name;

                MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statmentid);

                SqlCommandType sqlCommandType = mappedStatement.getSqlCommandType();

                switch (sqlCommandType){
                    case INSERT:
                        insert(statmentid, args);
                        break;
                    case UPDATE:
                        update(statmentid, args);
                        break;
                    case DELETE:
                        delete(statmentid, args);
                        break;
                    case SELECT:
                        // 获取被调用方法的返回值类型
                        Type genericReturnType = method.getGenericReturnType();

                        // 判断是否进行了泛型类型参数化
                        if (genericReturnType instanceof ParameterizedType) {
                            List<Object> objects = selectList(statmentid, args);
                            return objects;
                        }else{
                            return selectOne(statmentid, args);
                        }
                }

                // 获取被调用方法的返回值类型
//                Type genericReturnType = method.getGenericReturnType();
//
//                // 判断是否进行了泛型类型参数化
//                if (genericReturnType instanceof ParameterizedType) {
//                    List<Object> objects = selectList(statmentid, args);
//                    return objects;
//                }
//                return selectOne(statmentid, args);
                return "";
            }
        });
        return (T)proxyInstance;
    }

}
