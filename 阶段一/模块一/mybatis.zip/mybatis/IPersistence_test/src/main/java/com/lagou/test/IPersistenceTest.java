package com.lagou.test;

import com.lagou.dao.IUserDao;
import com.lagou.io.Resources;
import com.lagou.pojo.User;
import com.lagou.sqlSession.SqlSession;
import com.lagou.sqlSession.SqlSessionFactory;
import com.lagou.sqlSession.SqlSessionFactoryBuilder;
import org.dom4j.DocumentException;
import org.junit.Test;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;

public class IPersistenceTest {

    @Test
    public void test() throws Exception {

        // 将sqlMapConfig.xml生成输入流
        InputStream sqlMapConfig = Resources.getResourceAsStream("sqlMapConfig.xml");

        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();

        // 将配置文件解析并存储到javabean
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(sqlMapConfig);

        // 获取sqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(3);
        user.setUsername("张三");

        IUserDao iUserDao = sqlSession.getMapper(IUserDao.class);

        List<User> users = iUserDao.findAll();

        for (User user1 : users) {
            System.out.println(user1.getId() + "," + user1.getUsername());
        }
    }

    @Test
    public void updateTest() throws Exception {
        // 将sqlMapConfig.xml生成输入流
        InputStream sqlMapConfig = Resources.getResourceAsStream("sqlMapConfig.xml");

        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();

        // 将配置文件解析并存储到javabean
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(sqlMapConfig);

        // 获取sqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(4);
        user.setUsername("小李");

        IUserDao iUserDao = sqlSession.getMapper(IUserDao.class);
        iUserDao.updateUser(user);
    }

    @Test
    public void insertTest() throws Exception {
        // 将sqlMapConfig.xml生成输入流
        InputStream sqlMapConfig = Resources.getResourceAsStream("sqlMapConfig.xml");

        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();

        // 将配置文件解析并存储到javabean
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(sqlMapConfig);

        // 获取sqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(6);
        user.setUsername("小马哥");

        IUserDao iUserDao = sqlSession.getMapper(IUserDao.class);
        iUserDao.addUser(user);
    }

    @Test
    public void deleteTest() throws Exception {
        // 将sqlMapConfig.xml生成输入流
        InputStream sqlMapConfig = Resources.getResourceAsStream("sqlMapConfig.xml");

        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();

        // 将配置文件解析并存储到javabean
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(sqlMapConfig);

        // 获取sqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();

        User user = new User();
        user.setId(6);

        IUserDao iUserDao = sqlSession.getMapper(IUserDao.class);
        iUserDao.deleteUser(user);
    }
}
