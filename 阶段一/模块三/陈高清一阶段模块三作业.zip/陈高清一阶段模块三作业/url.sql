
url : http://127.0.0.1:8080/demo/query?username=chen
该地址允许用户 : chen,lisi  登录

url : http://127.0.0.1:8080/demo/query?username=xiaochen
该地址允许用户 : xiaochen,xiaoli  登录